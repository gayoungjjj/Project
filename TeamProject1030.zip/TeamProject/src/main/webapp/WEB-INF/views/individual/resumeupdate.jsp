<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Insert title here</title>
<link rel="stylesheet"  href="/css/common.css" />
<link rel="icon" type="image/png" href="/img/favicon.png" />

<style>
.div3{
background-color:#F7F7F7;
padding-top: 20px;
padding-bottom: 20px;
display:flex;
justify-content: center;
align-items: center;

}
  
/*이력서 css */

.resumeinput1{
width:150px;
height: 50px;
border: 1px #DDDDDD solid; 
}

.resumeinput2{
width:800px;
height:300px;
resize: none;
border: 1px #DDDDDD solid; }

.resumetable{
background-color:white;
padding: 10px 10px;
border: 1px solid #DBE0E9;
}

/*수정됨*/
.button-container {             
    display: flex;
    justify-content: center; 
    align-items: center; 
    padding-top: 20px;
}

/*수정됨*/
.asidesubmit{

  background-color:#4c5cc5;
  font-weight:bolder;
  font-size:15px;
  color:white;
  width:200px;
  margin-bottom:10px;
  height:40px;
  border: 1px #DDDDDD solid; 
  border-radius: 20px;
}

.red{
color: red;
}
/*이력서 css (끝)*/

</style>

</head>
<body>

<header style="margin-bottom: 10px;">
  <div class = "div1">
 	 <h1 class ="logo">
  		<a href="/Individual/Main?user_id=${param.user_id}"><img src="/img/로고.png"  alt=회사로고/></a>
 	 </h1>
 	 
    	 <div class="search">
  		<input type="text" placeholder="#픽미 는 당신의 취업을 응원합니다!! ">
  		<img src="https://s3.ap-northeast-2.amazonaws.com/cdn.wecode.co.kr/icon/search.png" >
		</div>
 

   <nav class ="headernav">
    <ul class ="leftmenu"> 
   			<li><a href="/Individual/Postlist?user_id=${param.user_id}">채용공고</a></li>
   			<li><a href="/Individual/Resumereg?user_id=${param.user_id}">이력서 등록</a></li>
    		<li><a href="/Individual/ResumeList?user_id=${param.user_id}">등록 이력서 관리</a></li>  		
    		<li><a href="/Individual/Recommend?user_id=${param.user_id}">기업 추천</a></li>
            <li><a href="/Individual/Cslist?user_id=${param.user_id}">고객센터</a></li>  
     </ul>   
     	 
    	 <div>
    		 <ul class="rightmenu"> 
     		 <li><a href="/Individual/Logout">로그아웃</a></li>
     		 <li><a href="/Individual/Mypage?user_id=${param.user_id}">마이페이지</a></li>
    		 </ul>
   		  </div>
   	 </nav>
   	</div> 
  </header>
  
<div class= "div2">
<a href="/Company/Main"><img src="/img/examplebanner.png" alt="예시 배너"></a>
</div> 

 <body>
<div class="div3">
 <form id="UpdateForm" action="/Individual/Updating"   method="POST">
  <h2 style="margin-top: -5px;text-align: center;">이력서수정</h2>


 
  <table class= "totaltable" style="border: 1px #DDDDDD solid; padding: 30px; background-color: #E8ECEF ">
  	<tr>
  	   <td>
  	   
         <h3 style="margin-top: -18px;">이력서 제목<span class="red" style="font-size: 11px;"> * 이력서 제목은 수정이 불가합니다. </span></h3> 
 			<table class ="resumetable" >
  		  	<tr>
          		<td style="width:800px;">
            	<input class="resumeinput1" type="text" name="title" value="${vo.title }" style="width:800px; height:50px; font-size: 18px;"  readonly> 
		        </td>
   			 </tr>
	</table>
 
 
  <h3>인적사항<span class="red" style="font-size: 11px;"> * 생년월일,성별,비상연락처를 제외한 인적사항은 마이페이지 회원정보수정을 통해 변경해주십시오.</span></h3>  
    <table class ="resumetable" >
    <tr>
        <td style="padding-top:10px; width:800px;"> 
        <input type="hidden" name="user_id" value="${param.user_id}">
            <input class="resumeinput1" type="text" name="username" value="${vo.username}" readonly>
        	<input class="resumeinput1" type="text" name="birth"  value="${vo.birth}" readonly>
            <select class="resumeinput1" name="gender"> 
                <option value="${vo.gender}">${vo.gender}</option>
                <option value="">성별(필수)</option> 
                <option value="남자">남자</option>
                <option value="여자">여자</option>
           	</select>
           	<input class="resumeinput1" type="text"     name="email"  value="${vo.email}" style="width:321px;" readonly>
                <br><p>
            	<input class="resumeinput1" type="text" name="number2"    value="${vo.number2}"  style="width:200px;">
            	<input class="resumeinput1" type="text" name="phone_number"  value="${vo.phone_number}"  style="width:200px;" readonly>
            	<input class="resumeinput1" type="text" name="address"  value="${vo.address}" style="width:377px;height: 50px;border: 1px #DDDDDD solid ;" readonly>            
         </td>
    </tr>
	</table>

<h3>경력사항</h3> 
    <table class ="resumetable">
       <tr>
         <td style="width:800px;" >
                  
           <select class="resumeinput1" name="career" > 
        		<option value="${vo.career}">${vo.career}</option>
     		    <option value="">경력(필수)</option>
        		<option value="신입">신입</option>
        		<option value="경력(1년 이상)">경력(1년 이상)</option>
        		<option value="경력(3년 이상)">경력(3년 이상)</option>
        		        		
          </select>
       	   <input class="resumeinput1" type="text"  name ="careers"  value="${vo.careers}" style="width:640px;" >
       	   
        </td>
      </tr>
	</table>


  <h3>학력사항</h3> 
    <table class ="resumetable">
    <tr>
    
       <td style="width:800px;">

    <input class="resumeinput1" type="text" name="eduwhen"   value="${vo.eduwhen}" style="width:250px;" > 
    <input class="resumeinput1" type="text" name="eduwher"  value="${vo.eduwher}">
    


        <select class="resumeinput1" name="edu" style="width:220px;"> 
        		<option value="${vo.edu }">${vo.edu }</option>
        		<option value="">최종학력(필수)</option>
        		<option value="학위(석사,박사)/(취득/예정)">학위(석사,박사)/(취득/예정)</option>
        		<option value="대학교(4년)/(졸업/예정)">대학교(4년)/(졸업/예정)</option>
        		<option value="대학(2년)/(졸업/예정)">대학(2년)/(졸업/예정) </option>
        		<option value="고등학교/(졸업/예정)">고등학교/(졸업/예정) </option>
        		<option value="기타">기타 </option>

        </select>
    
        

        
        <input class="resumeinput1" type="text" name= "major"  value="${vo.major}" style="width:158px;">
        </td>
    </tr>
	</table>
    

<h3>자격증</h3> 
    <table class ="resumetable">
       <tr>
         <td style="width:800px;">
       	   <input class="resumeinput1" type="text" name="licenses1"   value="${vo.licenses1}" >
       	   <input class="resumeinput1" type="text" name="publisher1"  value="${vo.publisher1}">
           <input class="resumeinput1" type="date" name="passdate1"   value="${vo.passdate1}" > 
           <input class="resumeinput1" type="text" value="예시) 컴퓨터활용1급" style="margin-left: 5px;" readonly>
           <input class="resumeinput1" type="text" value="예시) 대한상공회의소" readonly>
           <br><p>
       	   <input class="resumeinput1" type="text" name="licenses2"  value="${vo.licenses2}" >
       	   <input class="resumeinput1" type="text" name="publisher2" value="${vo.publisher2}">
           <input class="resumeinput1" type="date" name="passdate2"  value="${vo.passdate2}" >

           <br><p>
       	   <input class="resumeinput1" type="text" name="licenses3"  value="${vo.licenses3}" >
       	   <input class="resumeinput1" type="text" name="publisher3" value="${vo.publisher3}" >
           <input class="resumeinput1" type="date" name="passdate3"  value="${vo.passdate3}" >
        </td>
      </tr>
	</table>




<h3>보유기술 및 능력</h3> 
    <table class ="resumetable">
      <tr>
        <td style="width:800px;">
       	   <input class="resumeinput1" type="text" name="skills1" value="${vo.skills1}">
		   <input class="resumeinput1" type="text" name="skills2" value="${vo.skills2}">
		   <input class="resumeinput1" type="text" name="skills3" value="${vo.skills3}">
		   <input class="resumeinput1" type="text" name="skills4" value="${vo.skills4}">
		   <input class="resumeinput1" type="text" name="skills5" value="${vo.skills5}">
	    </td>
      </tr>
	</table>

   
   
<h3>포트폴리오</h3> 
    <table class ="resumetable">
      <tr>
        <td style="width:800px;">
		   <input class="resumeinput1" type="text" name="portfolio" value="${vo.portfolio}"style="width:500px;">
		   <input class="test" type="file" value="파일첨부" style="margin-left: 20px">
        </td>
      </tr>
	</table>
  

 <h3>자기소개서</h3> 
    <table class ="resumetable">
      <tr>
        <td style="width:800px;">
		   <textarea class = "resumeinput2" rows="10" cols="50" name="selfintro"  >${vo.selfintro}</textarea></td>		
      </tr>
	</table>
	
	
	   <!--  수정됨  --> 
	<div class="button-container">
    <table>
        <tr>
            <td class="endbutton">
                <button class="asidesubmit"  type="submit"  id="checkForm">수정완료</button>   
                <input class="asidesubmit" type="button" value="이전으로" id="goList" style="background-color: white; color: black">
            </td> 
        </tr>
    </table>
</div>
	
	
    </td>
    </tr>  
     </table>
      </form>
</div>
   
 <!-- 이름 추가, 아이디 x ,공고제목 , 경력 ,학력 ,기술 ,자격증 ,포트폴리오 , 자기소개서 --> 
  
 <footer>
  <div class="footer1">
   <p><small>&copy; 2024 All rights reserved 픽미</small></p>
  </div>
 </footer>

<script>
const  goList = document.getElementById('goList')
goList.onclick = function() {
   location.href = '/Individual/ResumeList?user_id=${param.user_id}'
} ;


document.getElementById('checkForm').onclick = function(event) {
    event.preventDefault(); // 기본 제출 동작 방지

    const title = document.querySelector('input[name="title"]');
    const birth = document.querySelector('input[name="birth"]');
    const gender = document.querySelector('select[name="gender"]');
    const career = document.querySelector('select[name="career"]');
    const edu = document.querySelector('select[name="edu"]');

    // 필수 입력란 검증
    if (!title.value ) {
        alert("제목을 입력해 주세요.");
        title.focus();
        return false;
    }
    if (birth.value.length !== 8) {
        alert("생년월일을 다시 확인해 주세요.\n (예시) 20241029 ");
        birth.focus();
        return false;
    }
    if (gender.value === "") {
        alert("성별을 선택해 주세요.");
        gender.focus();
        return false;
    }
    if (career.value === "") {
        alert("경력을 선택해 주세요.");
        career.focus();
        return false;
    }
    if (edu.value === "") {
        alert("최종 학력을 선택해 주세요.");
        edu.focus();
        return false;
    }

    // 모든 검증 통과 후 폼 제출
    document.getElementById('UpdateForm').submit();
};
</script>

</body>
</html>